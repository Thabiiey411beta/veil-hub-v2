+# DEPLOYMENT-SUPRA — Veil Hub (Supra Relayer) Deployment Guide
+
+Overview
+- This doc describes deploying Veil Hub components that rely on Supra relayers and cross-chain messaging, including node, relayer, and docker-compose patterns.
+
+Prerequisites
+- Linux environment with Docker & docker-compose installed.
+- Access to Supra relayer credentials and network endpoints.
+- Wallets and keys provisioned for deployer and multisig.
+
+High-Level Steps
+1. Prepare environment variables and .env files for relayers and contracts.
+2. Build and deploy local or testnet containers (see docker-compose.supra.yml).
+3. Initialize Supra relayer profiles and import keys.
+4. Deploy contracts (Move or Solidity) to target chains via provided scripts.
+5. Verify bridge connectivity and run end-to-end tests.
+
+Scripts & Helpers
+- upstream/scripts/setup-supra-cli.sh: prepares Supra CLI environment.
+- upstream/scripts/enter-supra.sh: enter the Supra runtime environment.
+- upstream/scripts/deploy-contracts.sh: contract deployment orchestration.
+
+Sample Deployment (testnet)
+- Create `.env` with SUPRA_RPC, RELAYER_KEY, DEPLOYER_ADDRESS, NETWORK=veil-testnet
+- Start services:
+
+  docker compose -f docker-compose.supra.yml up --build -d
+
+- Initialize relayer profile:
+
+  ./upstream/scripts/supra-profile-new.sh --name veil-relayer --key $RELAYER_KEY --network $NETWORK
+
+- Deploy contracts:
+
+  ./upstream/scripts/deploy-contracts.sh --network $NETWORK --deployer $DEPLOYER_ADDRESS
+
+Verification
+- Check relayer logs for message receipts and confirmations.
+- Validate contracts on chain via explorers and run integration tests in `upstream/`.
+
+Security Notes
+- Keep relayer keys in HSM/KMS where possible.
+- Restrict network access to relayer RPC endpoints using firewall rules and allowlists.
+
+Rollback
+- Keep transaction nonces and deployment manifests; use multisig to pause or revert bridging if anomalies appear.
+