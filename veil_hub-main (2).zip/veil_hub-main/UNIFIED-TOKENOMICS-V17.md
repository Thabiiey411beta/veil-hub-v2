# Unified Tokenomics — V17

Version: 17
Last updated: 2025-12-19

Summary
- Purpose: define supply, distribution, emission schedules, incentives, fee logic, governance staking, burn mechanisms, and economic risk controls for Veil Hub V17.

Key Principles
- Predictability: deterministic schedules for base emissions and epoch updates.
- Sustainability: alignment of protocol fees and buyback/burn to reduce inflationary pressure.
- Incentive alignment: long-term staking rewards and ve-style locking for governance power.
- Flexibility: parameter governance via on-chain proposals with timelocks.

Token Supply and Types
- VEIL: native utility/governance token. Initial total supply: 1,000,000,000 VEIL (configurable by genesis governance). Minting strictly controlled via governance and capped emission schedules.
- sVEIL (staked VEIL / ve-VEIL): time-locked token representing locked voting power and boostable yield share.

Emission Schedule
- Genesis allocation: 20% ecosystem (team, treasury, early backers), 10% liquidity bootstrap, 5% advisors, 65% protocol emission over 8 years.
- Linear-decay emission model: weekly epoch emissions reduce by a fixed decay factor until a steady-state annual inflation (~1–2%) is reached.
- Emission destinations: liquidity mining (40% of epoch), staking rewards (30%), protocol treasury (15%), developer grants & security (10%), community incentives (5%).

Staking & Locking (ve-model)
- Users lock VEIL for sVEIL (time-weighted) to gain boosted yields and voting power. Lock durations scale linearly up to 4 years for maximum boost.
- Reward split: base rewards to all stakers, boost multiplier for sVEIL holders increases portion attributed to locked users.

Fees, Buyback & Burn
- Protocol fees (fees on swaps, index adjustments, streaming fees) split: 50% to treasury, 30% to buyback+burn, 20% to stakers as fee-distribution.
- Buyback mechanism: treasury uses collected fees to purchase VEIL on open markets and burn or redistribute per governance decisions.

Deflationary Controls
- Emergency burn: governance can vote to sink tokens for long-term supply control.
- Treasury buyback floor/ceiling to avoid excessive market impact.

Governance & Timelocks
- Parameter changes require an on-chain proposal and a default 7-day timelock; critical security updates may use a multisig/emergency governance flow.
- Upgradeability limited to modules explicitly marked upgradeable; core economics are intentionally immutable without supermajority.

Indices & Fees
- Phantom indices collect small streaming and reweight fees; fees route to treasury and buyback to support VEIL value.

Risk Controls
- Supply caps, proposal emission increase veto windows, and quarterly treasury spending caps protect against runaway inflation and misuse.

Telemetry & Oracles
- Emissions & economic parameters exported via read-only oracles for UIs and risk dashboards.

Appendix: Default Parameters (template)
- Total supply: 1,000,000,000 VEIL
- Initial emission horizon: 8 years
- Max lock duration: 4 years
- Governance timelock: 7 days
- Fee split (treasury/buyback/stakers): 50/30/20

Notes
- Numeric defaults are templates — final values must be set in genesis or an initial governance migration proposal.
