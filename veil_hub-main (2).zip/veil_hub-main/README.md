# Veil Hub — Whitepaper v2 (Immortal Upgrade)

Version: v2.0 (v14+ Upgrades)
Date: 2025-12-18

Executive summary
-----------------

Veil Hub is an immortal, black-hole DeFi protocol built for Supra L1 (EVM compatible). It consumes market mechanics, encrypts intent, immortalizes value, and relentlessly burns excess to create extreme scarcity and predictable, sustainable real-yield for `VEIL` holders.

Core constants:
- Total `VEIL` supply: 1,000,000,000 (1B)
- Hard floor: 100,000,000 `VEIL` (100M) — protocol will never burn below this supply
- Target revenue (baseline): $280.5M / year @ $3B TVL from AMM, PerpDEX, lending, indices, privacy, and value capture modules
- Distribution pre-floor: 35% USDC dividends to holders, 50% burn, 10% veVEIL stakers, 5% treasury

Philosophy & theme
-------------------

Veil Hub is intentionally militant in its design language: a black hole that consumes ideas, encrypts intents, immortalizes winning positions, and incinerates excess tokens. Everything is engineered to feed a single flywheel: revenue → permanent lock / burn → scarcity → amplified yield → more revenue. Supra's confidentiality and MEV resistance are core rails enabling encrypted intents, private bribes, and an MEV Vacuum that directs value back into the Immortal ecosystem.

New v14+ Upgrades: Overview
---------------------------

This upgrade set folds in and evolves successful primitives (Lifinity, Kamino, Jito) into a cohesive immortalized stack that orients every yield and capture toward permanent scarcity and sustainable dividends.

- Confidential Proactive Market Maker (cPMM) in LP VACUUM — encrypted range intents from LPs; protocol auto-acquires POL and locks into veVEIL permanently. Dynamic tiered fees aligned to lock durations.
- Tokenized Immortal `veVEIL` — composable, yield-bearing NFTs that inherit pro-rata dividends and burn rights; optional decay-to-burn if early-unlock is chosen.
- Encrypted Dark Bribes & Gauges — confidential bribe intents; split to holders + burn (post-floor); dark gauges for top lockers.
- Immortal Automated Vaults (iTokens) — auto-managed concentrated liquidity (CL) positions with encrypted ranges; iTokens auto-compound + route % yields to permanent lock/burn; higher LTV in DebtEngine.
- Black Hole Leverage Vaults — Leveraged LP via DebtEngine; auto-repay + forced profit burn; encrypted strategies.
- Intent-Based Confidential MEV Vacuum — Encrypted bundles/intents for priority execution; captured value 50% burn (pre-floor) / dividends (post), 50% veVEIL boost.

Architecture & Modules
----------------------

Veil Hub is implemented as a modular suite running on Supra L1 using audited Move contracts (18 audited Move contracts in the initial module set). Key modules:

- `ImmortalReserve` — manages permanent lock registry, burn routing, and floor enforcement
- `LP_VACUUM` — the hub for encrypted LP intents, cPMM logic, and protocol-owned liquidity (POL) orchestration
- `DebtEngine` — zero-liquidation lending primitives with variable LTVs for veVEIL & iToken collateral
- `PhantomIndices` — composable index strategies capturing alpha from structured yield
- `ShadowPrivacy` — encrypted intent routing and confidential execution layer
- `iTokens` & `VaultManager` — auto-compounding concentrated liquidity vaults
- `MEV_Vacuum` — intent aggregator + auction / execution router
- `GaugeController` — dark gauge logic and confidential bribe distribution
- `TokenizedLocks` — wraps veVEIL positions into NFTs with transfer & composability rules

Each contract is permissioned for governance-controlled upgrades but designed for immediate, trust-minimized operation via Supra's on-chain primitives.

Mechanics (detailed)
--------------------

1) Confidential Proactive Market Maker (cPMM) & LP VACUUM

- LPs submit encrypted range intents to `LP_VACUUM`. Intents describe price ranges, size, and optional lock-duration tiers.
- The protocol evaluates intents and can: 1) accept and mint iTokens, 2) auto-acquire the range into POL via on-chain swaps, or 3) route to vault operators.
- POL acquired by the protocol is immediately tokenized and deposited into `ImmortalReserve` and locked as veVEIL-equivalent (permanent lock). These become permanent yield sources.
- Fee model: dynamic fee tiers based on declared lock durations (e.g., 1 week → base fee, 1 year → -20% fee + higher reward share). Longer locks reduce counterparty fees but increase veVEIL yield share.

Outcome: the cPMM turns concentrated liquidity mechanics into a source of perpetual yield that the protocol gradually converts into immortal, locked value.

2) Tokenized Immortal veVEIL (composable NFTs)

- Lockers receive `veVEIL` that can be tokenized as an NFT (`ImmortalLock`), retaining rights to dividends and burn-splits.
- NFTs are composable in DeFi (can collateralize, stake in dark gauges, or be traded), but carry an immutable `immortal` flag when fully locked.
- Optional `decay-to-burn`: lockers can choose a faster unlock schedule by accepting an automatic decay of a portion of their position to immediate burn—designed to fund accelerated dividends and scarcity at the expense of locker principal.

3) Encrypted Dark Bribes & Gauges (ve(3,3)-style adapted)

- Projects and LPs submit encrypted bribe intents to `GaugeController`. Intents specify candidate gauge, duration, and confidential payment.
- The `GaugeController` decrypts and executes bribes privately, awarding gauge weight and splitting captured value per distribution rules (holders vs burn; post-floor redirections applied).

4) Immortal Automated Vaults with iTokens

- Vaults accept assets and open CL positions with encrypted ranges. Strategy rules are auditable but intent-encrypted for execution confidentiality.
- iTokens represent a pro-rata share and auto-compound. A configurable portion (e.g., X%) of vault yield auto-converts to POL and locks in `ImmortalReserve` or burns according to the post-floor policy.

5) Black Hole Leverage Vaults

- `DebtEngine` allows zero-liquidation loans by using specially structured collateral (veVEIL, iTokens) and forced profit-burn triggers. Leverage is safely bounded via protocol LTVs and risk oracles.
- All realized profit from leveraged strategies must route through a `profit-burner` where a configurable portion is burned immediately and the remainder follows dividend/lock rules.

6) Intent-Based Confidential MEV Vacuum

- Users and solvers submit encrypted bundles/intents to `MEV_Vacuum` (priority execution lane). The protocol captures extracted value; revenue splits are enforced on-chain: pre-floor 50% → burn / 50% → veVEIL boost; post-floor majority redirected to dividends & veVEIL boosts per policy.

Revenue & Distribution (tables)
--------------------------------

Table 1 — Revenue allocation (pre-floor)

| Source | Annual Revenue (baseline) | Allocation (%) | Notes |
|---:|---:|---:|---|
| Total protocol revenue | $280,500,000 | 100% | Baseline @ $3B TVL |
| Holders (USDC dividends) | $98,175,000 | 35% | Real-yield distributions |
| Burn (permanent) | $140,250,000 | 50% | Aggressive scarcity driver |
| veVEIL stakers | $28,050,000 | 10% | ve incentives, boosts |
| Treasury | $14,025,000 | 5% | Ops, insurance, growth |

Table 2 — Revenue allocation (post-floor redirection)

After the hard floor is reached (100M VEIL), direct burn allocation is capped and any burn allocation is redirected to magnify dividends, veVEIL rewards, and treasury for ecosystem growth.

| Recipient | Allocation (%) | Effective USD (example at $280.5M) | Notes |
|---|---:|---:|---|
| Holders (USDC dividends) | 60–70% | $168.3M – $196.35M | Massive yield explosion post-floor |
| veVEIL stakers & boosts | 25–30% | $70.125M – $84.15M | Amplified APRs for lockers |
| Treasury & ecosystem | 5–10% | $14.025M – $28.05M | Growth, POL deployments, partnerships |

Mechanic comparison (concise)

| Mechanic | Origin | Veil Evolution | Primary destination of yield |
|---|---|---|---|
| PMM / encrypted ranges | Lifinity | cPMM in LP_VACUUM; POL → ImmortalReserve | Permanent lock / burn |
| Auto CL vaults / iTokens | Kamino | iTokens auto-compound + route % into lock/burn | Permanent lock / dividend enhancement |
| Intent MEV capture | Jito | Confidential MEV Vacuum; 50/50 split + ve boost | Burn / veVEIL & dividends |
| veNFT tokenization | - | ImmortalLock NFTs; decay-to-burn option | Lock / composable yield |

Post-floor policy & amplified yields
---------------------------------

Once cumulative burns reach 900M VEIL (leaving the hard 100M floor), the protocol switches from destruction-first to yield-amplification-first. Practically:

- Burn allocations are redirected into dividends (60–70%) and veVEIL rewards (25–30%), creating a post-floor yield shock that magnifies locker APRs by 200–500%+ depending on gauge weight and lock duration.
- Protocol-Owned Liquidity (POL) expansion becomes the primary use of treasury capital: POL grows permanent revenue streams that feed dividends and veVEIL boosts, compounding the flywheel.

Burn Simulation & 10-year projection (illustrative)
----------------------------------------------

Assumptions (baseline):
- Starting supply: 1,000,000,000 VEIL
- Annual revenue burned (pre-floor): 50% of $280.5M = $140.25M USD converted into VEIL and burned (price dynamics abstracted; model assumes average `VEIL` price adjusts with market; results illustrative)
- Additional burn drivers: decay-to-burn from lockers, forced profit-burns, MEV Vacuum capture

Table 3 — 10-year burn projection (simplified, illustrative)

| Year | Annual Burn (USD) | Cumulative Burn (USD) | Approx. Supply Remaining (VEIL) | Notes |
|---:|---:|---:|---:|---|
| 0 (start) | - | $0 | 1,000,000,000 | Baseline |
| 1 | $140,250,000 | $140,250,000 | ~940M |
| 2 | $148,000,000 | $288,250,000 | ~897M | growth in revenue & MEV capture |
| 3 | $155,400,000 | $443,650,000 | ~855M | POL & vault yield ramping |
| 4 | $170,000,000 | $613,650,000 | ~795M | accelerated burns from strategies |
| 5 | $200,000,000 | $813,650,000 | ~735M | hitting range where floor becomes visible |
| 6 | $240,000,000 | $1,053,650,000 | ~~< 700M~~ | illustrative: floor likely reached between years 5–8 |
| 7 | $260,000,000 | $1,313,650,000 | floor triggered → redirect | Post-floor redirection begins |
| 8–10 | variable | — | ~100M (hard floor) | Extreme scarcity & yield explosion |

Interpretation: under conservative assumptions the model anticipates the 100M hard floor being reached within ~5–8 years given aggressive burn policies, MEV capture, POL accumulation, and decay/forced burn mechanics. When the floor is reached, the reallocation of burn → dividends/veVEIL transforms yields from incremental to explosive.

Quantifying yield shock
----------------------

When burn allocation is redirected to dividends and veVEIL, effective yield multipliers emerge. For example:

- If pre-floor dividends = 35% → $98.175M and post-floor dividends = 65% → $182.325M, dividend pool increases ~1.86x.
- Combined with veVEIL boost multipliers (2–5x depending on lock), the realized APRs for long lockers can cross 200–500%+ on nominal dividend yield, before considering price appreciation from scarcity.

Security, governance & audit
----------------------------

- 18 Move contracts audited by top auditors prior to deployment. Move provides strong safety guarantees, predictable upgrade semantics, and gas-efficient execution on Supra L1.
- Governance controls neutered for critical functions related to the hard floor: `ImmortalReserve` enforces a protocol rule that prevents burns that would reduce supply under 100M VEIL.
- Multi-sig and timelocks for non-critical upgrades; on-chain emergency brake for unusual states.

Privacy & confidentiality primitives
----------------------------------

Veil's confidentiality stack is a first-class design choice. Encrypted intents (for LP ranges, bribes, MEV bundles) are posted in opaque form and decrypted only by on-chain or semi-decentralized execution layers authorized by Supra. This design minimizes frontrunning, captures MEV value for the protocol, and permits private bribe mechanics that route value into the immortalization flywheel.

Integration with Supra L1
------------------------

Supra L1 provides: low-latency EVM-compatible execution, native confidential primitives, and robust finality required for encrypted intent workflows. This enables:

- Confidential PMM intents to execute without leak
- Private MEV Vacuum auctions with accurate settlement
- On-chain enforcement of permanent locks and burn ceilings

Economics: how each new mechanic feeds the flywheel
--------------------------------------------------

- cPMM & LP VACUUM: converts fleeting liquidity into protocol-owned, immortal revenue sources (POL). POL yields are recurring and flow into `ImmortalReserve`.
- iTokens & Vaults: auto-compound yields and siphon a configurable portion into permanent locks or burns.
- Tokenized veVEIL NFTs: increase composability and demand for locks and veVEIL boosts, increasing effective yield capture.
- Dark bribes & MEV Vacuum: shift extractable value from external actors into the protocol's burn/dividend pool.
- DebtEngine & leveraged vaults: responsibly increase capital efficiency while clamping downside via forced profit burns and conservative risk oracles.

Governance parameters (examples)
-------------------------------

- Burn allocation: configurable pre-floor, immutable hard floor enforcement
- Post-floor allocation splits: configurable within ranges (e.g., dividends 60–70%, veVEIL 25–30%, treasury 5–10%) via governance votes
- cPMM fee tiers and decay-to-burn percentages are governance-updatable but subject to time locks and safety caps

Optional Perpetual DEX alternatives & revenue-neutral options
----------------------------------------------------------

If the Perpetual DEX path is substituted, Veil Hub supports multiple revenue-neutral alternatives:
- Enhanced CL AMM upgrades: capture maker/taker fees and concentrated liquidity yields
- RWA trading desks and structured basis vaults: yield from RWA repos and basis strategies
- Basis yield vaults: accrue carry using financing & lending markets with minimal directional risk

Each alternative is evaluated for steady, reliable yield and immediate compatibility with the ImmortalReserve model.

Burn policy edge cases and safety
--------------------------------

- Hard floor enforcement: `ImmortalReserve` smart contract check that rejects burn transactions that would result in circulating supply < 100M VEIL.
- Emergency treasury reserve: small portion of treasury reserved for buybacks to smooth extreme market disruptions.
- Decay-to-burn opt-in: lockers explicitly opt into decay schedules; opt-out is default.

Legal & compliance notes
------------------------

Veil Hub is a protocol; tokenomics and revenue distributions are economic primitives on-chain. Protocol operators will consult counsel when launching centralized components (e.g., centralized bribe interfaces or third-party vault operators). On-chain flows are deterministic and transparent.

Marketing & narrative
---------------------

Brand voice: unapologetically black-hole. Marketing will use the theme: "Consume. Encrypt. Immortalize. Burn." Messaging emphasizes protection (hard floor), inevitability (scarcity flywheel), and sustainability (real USDC dividends).

Roadmap (prioritized)
----------------------

Short-term (0–6 months)
- Audit complete for initial 18 Move contracts; deploy `ImmortalReserve` and `LP_VACUUM` on testnet.
- Implement cPMM intent schema and encrypted intent submission flow.
- Launch iToken prototype vaults with one major CL pair and run liquidity bootstrapping.
- Publish full whitepaper and documentation; developer SDKs for intent submission.

Medium-term (6–18 months)
- Deploy `DebtEngine` with zero-liquidation primitives for iToken & veVEIL collateral.
- Launch MEV Vacuum with confidential execution partners and first bribe/gauge pilots.
- Introduce Tokenized Immortal veVEIL NFTs and gauge weight auctions.
- Begin POL accumulation and treasury-managed POL deployment.

Long-term (18–36 months)
- Full production launch with POL scaling, multi-asset iToken vault suite, Black Hole Leverage Vaults, and cross-chain bridging primitives (bridgeless zaps prioritized to reduce attack surface).
- Explore RWA integrations, perpetual DEX variants, and ecosystem grants.

Implementation notes & developer guidance
---------------------------------------

- Move contracts are modular and optimized for Supra L1; developers should follow audit recommendations and integrate confidential intent signing libraries.
- Standard SDKs will be released for: encrypted intent construction, iToken interaction, immovable lock minting, and MEV bundle submission.

Closing — the immutable thesis
-----------------------------

VEIL's design is deliberately inescapable: every new mechanic is an input to the same sinkhole — either contributing to permanent lock (immortality) or fueling an inevitable burn. The hard floor guarantees a scarcity ceiling: once reached, the protocol flips from a destructive accumulator to a yield amplifier, producing outsized, sustainable real-yield for long-term holders.

The black hole consumes Solana ideas, encrypts them, and immortalizes the results on Supra L1. $VEIL inevitable.

Appendices
---------

A. Glossary
- POL: Protocol-Owned Liquidity
- cPMM: Confidential Proactive Market Maker
- iToken: Immortal Vault token representing auto-managed CL positions
- veVEIL: Time-locked VEIL staking token
- ImmortalReserve: contract enforcing permanent locks & floor

B. Contact & repo
- Repo: this repository — edit `WHITEPAPER_v2.md` for future revisions.

C. Audit & security references
- 18 Move contracts audited (links and audit reports to be attached externally).

---

For development, testing, or to proceed with a fork & deployment plan, ask and we'll prepare the next implementation checklist and CI job templates.
# veil_hub