# Veil Hub vImmortal — README

Overview
- Veil Hub vImmortal is a production-grade Move-suite for Supra L1 providing a composable DeFi organism: AMMs, perps, lending, vaults, gauges, restaking and treasury with built-in safety and upgrade patterns.

Core modules (located in `move_modules/`)
- `veil_token.move`: VEIL token supply and mint/burn hooks.
- `immortal_reserve.move`: Reserve with floor + post-floor redirect logic.
- `veveil.move`: tokenized veNFTs with decay-to-burn.
- `confidential_pmm.move`: AMM (PMM) with fee controls and oracle checks.
- `lp_vacuum.move`: LP vacuuming + restake orchestration.
- `debt_engine.move`: zero-liquidation debt design and O/C enforcement.
- `perpetual_dex.move`: perps with circuit breaker + external oracle hook.
- `immortal_vaults.move`: yield vaults with pause guards.
- `phantom_lender.move`: pooled lending (Morpho/Notional style) with O/C checks.
- `phantom_yield_spectrum.move`: yield strategies and RWA-ready hooks.
- `phantom_restaker.move`: automated restaker (1–2% restaking management).
- `phantom_symbiote.move`: cross-module orchestration primitives.
- `mev_vacuum.move`: MEV capture and allocation.
- `dark_gauges.move`: veVEIL-weighted gauge emissions.
- `treasury.move`: treasury with `InsuranceFund` auto-seeding and timelock hooks.
- `governance.move`: timelock/gov primitives (48h queue, pause flags).

Safety & Governance Highlights
- Timelocks: governance-only queued actions with 48-hour minimum delay enforced on critical state changes.
- Circuit breakers: per-module pause flags (checked on entry) and explicit circuit toggles for perps/lending/vaults.
- Insurance Fund: treasury automatically allocates 5–10% revenue to an `InsuranceFund` for the first 24 months (configurable via governance timelock).
- Oracle & ML hooks: modules include placeholders for external oracle feeds (SupraNova) and an AI governance assistant hook to receive strategy suggestions.

Parameters and Guardrails
- Over-collateralization: enforced 150–200% minimum in lending and debt modules.
- Health factor buffer: >1.3 enforced by checks before risky actions.
- Fee ranges: AMM 0.05–0.30%; perps ultra-low fees supported; lending 4–15%; yield trading 0.1–0.2%.
- Restaking management: 1–2% default.

Usage and Init Order
1. Deploy `governance.move` and initialize governance account via `governance::init`.
2. Deploy `vaults`, `treasury`, `veil_token`, and other core modules, calling their `example_init` or `init` functions.
3. Queue sensitive parameter changes via `governance::queue_action` (delay >= 48h). Apply after delay via module-specific `apply_queued_action` entry points.

Notion / Documentation
- I could not access Notion from this environment. To import these artifacts into Notion:
  - Copy the contents of this README and the whitepaper file into a Notion page.
  - Or use Notion's "Import" feature with a Markdown file export.

Next steps
- Run a target-specific Move compilation (Sui/Aptos/Supra) and implement target-specific storage/balance maps.
- Add comprehensive unit/integration tests for oracle, timelock, and circuit-breaker flows.

Contact
- For modifications, change proposals, or audits, open an issue in the repository or contact the engineering team.
