// SPDX-License-Identifier: MIT
pragma solidity ^0.8.17;

import "./VeilToken.sol";
import "./GovernanceTimelock.sol";

/**
 * @title Treasury
 * @notice Collects protocol revenue and auto-allocates a percent to InsuranceFund for first 24 months.
 * Insurance percent is in basis points (bps). Adjustable via governance timelock.
 */
contract Treasury {
    VeilToken public veil;
    GovernanceTimelock public timelock;

    uint256 public balance; // VEIL balance held
    uint256 public insuranceBalance;
    uint256 public insurancePercentBps; // e.g., 500 = 5%
    uint256 public launchTime;

    event RevenueCollected(uint256 amount, uint256 toInsurance, uint256 toTreasury);

    modifier onlyTimelock() {
        require(msg.sender == address(timelock), "Treasury: only timelock");
        _;
    }

    constructor(address _veil, address _timelock, uint256 _insurancePercentBps) {
        veil = VeilToken(_veil);
        timelock = GovernanceTimelock(_timelock);
        insurancePercentBps = _insurancePercentBps;
        launchTime = block.timestamp;
    }

    // Collect revenue (VEIL tokens). The caller should have transferred VEIL to this contract first.
    function collectRevenue(uint256 amount) external {
        require(veil.balanceOf(address(this)) + amount >= veil.balanceOf(address(this)), "overflow");
        // compute months since launch
        uint256 monthsSince = (block.timestamp - launchTime) / 30 days;
        uint256 allocBps = insurancePercentBps;
        if (monthsSince > 24) { allocBps = 0; }
        uint256 toInsurance = (amount * allocBps) / 10000;
        uint256 toTreasury = amount - toInsurance;
        insuranceBalance += toInsurance;
        balance += toTreasury;
        emit RevenueCollected(amount, toInsurance, toTreasury);
    }

    // Governance-timelock can update the insurance percent via a queued action that calls this.
    function updateInsurancePercent(uint256 newBps) external onlyTimelock {
        require(newBps <= 1000, "Treasury: max 10% enforced");
        insurancePercentBps = newBps;
    }

    // Withdraw functions for treasury and insurance (timelock only for safety)
    function withdrawTreasury(address to, uint256 amount) external onlyTimelock {
        require(balance >= amount, "Treasury: insufficient");
        balance -= amount;
        veil.transfer(to, amount);
    }

    function withdrawInsurance(address to, uint256 amount) external onlyTimelock {
        require(insuranceBalance >= amount, "Treasury: insufficient insurance");
        insuranceBalance -= amount;
        veil.transfer(to, amount);
    }
}
