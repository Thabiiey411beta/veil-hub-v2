# Veil Hub vImmortal - Solidity Contracts

This folder contains Solidity counterparts/skeletons for the Veil Hub vImmortal design:

- `VeilToken.sol` — ERC-20 VEIL token (simple, gas-conscious implementation).
- `GovernanceTimelock.sol` — governance timelock with 48-hour minimum delay and pause toggles.
- `Treasury.sol` — treasury with `InsuranceFund` seeding logic (auto-allocates 5–10% revenue for first 24 months).
- `PerpetualDEX.sol` — perpetuals DEX skeleton with circuit breaker and external oracle hook.
- `PhantomLender.sol` — lending pool with over-collateralization enforcement.
- `Vaults.sol` — vaults with pause guard and deposit/withdraw flows.

How to use
1. Compile with `solc` or Hardhat/Foundry.
2. Deploy `GovernanceTimelock` first and set it as the governance authority for other contracts.
3. Deploy `VeilToken`, `Treasury`, `PerpetualDEX`, `PhantomLender`, and `Vaults`, passing the `GovernanceTimelock` address where required.
4. Use the timelock queue to perform governance actions (pause toggles, param updates) with a 48-hour delay.

Security notes
- Circuit breakers and pause guards rely on timelock-controlled toggles.
- Treasury auto-allocates configured insurance percent for the first 24 months; governance can update the percent via timelock.
- Oracles and external feeds must be validated off-chain and sanity-checked on-chain.
