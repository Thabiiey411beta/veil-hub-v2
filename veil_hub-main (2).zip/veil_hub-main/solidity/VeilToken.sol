// SPDX-License-Identifier: MIT
pragma solidity ^0.8.17;

/**
 * @title VeilToken
 * @notice Minimal ERC20-like VEIL token used by Veil Hub. In production use OpenZeppelin ERC20.
 * Safety: basic checks and mint/burn restricted to governance address.
 */
contract VeilToken {
    string public name = "Veil Token";
    string public symbol = "VEIL";
    uint8 public decimals = 18;
    uint256 public totalSupply;

    address public governance;

    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    modifier onlyGovernance() {
        require(msg.sender == governance, "VEIL: only governance");
        _;
    }

    constructor(address _governance, uint256 _initial) {
        governance = _governance;
        _mint(msg.sender, _initial);
    }

    function transfer(address to, uint256 amount) external returns (bool) {
        _transfer(msg.sender, to, amount);
        return true;
    }

    function approve(address spender, uint256 amount) external returns (bool) {
        allowance[msg.sender][spender] = amount;
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        require(allowance[from][msg.sender] >= amount, "VEIL: allowance");
        allowance[from][msg.sender] -= amount;
        _transfer(from, to, amount);
        return true;
    }

    function _transfer(address from, address to, uint256 amount) internal {
        require(balanceOf[from] >= amount, "VEIL: balance");
        balanceOf[from] -= amount;
        balanceOf[to] += amount;
    }

    function _mint(address to, uint256 amount) internal {
        totalSupply += amount;
        balanceOf[to] += amount;
    }

    function mint(address to, uint256 amount) external onlyGovernance {
        _mint(to, amount);
    }

    function burn(address from, uint256 amount) external onlyGovernance {
        require(balanceOf[from] >= amount, "VEIL: burn balance");
        balanceOf[from] -= amount;
        totalSupply -= amount;
    }
}
