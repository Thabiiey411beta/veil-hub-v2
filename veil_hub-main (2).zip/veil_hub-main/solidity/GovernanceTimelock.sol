// SPDX-License-Identifier: MIT
pragma solidity ^0.8.17;

/**
 * @title GovernanceTimelock
 * @notice Timelock that enforces a minimum delay for governance actions (default 48 hours).
 * It also stores per-module pause flags which modules may query before executing critical operations.
 */
contract GovernanceTimelock {
    address public governor;
    uint256 public minDelay; // seconds

    struct Action {
        address target;
        bytes data;
        uint256 eta;
        bool executed;
    }

    uint256 public actionCount;
    mapping(uint256 => Action) public actions;

    mapping(bytes32 => bool) public pausedModules; // key = keccak256(moduleName)

    event QueueAction(uint256 indexed id, address target, bytes data, uint256 eta);
    event ExecuteAction(uint256 indexed id);
    event TogglePause(bytes32 indexed moduleKey, bool paused);

    modifier onlyGovernor() {
        require(msg.sender == governor, "Timelock: only governor");
        _;
    }

    constructor(address _governor, uint256 _minDelay) {
        governor = _governor;
        minDelay = _minDelay;
    }

    function queueAction(address target, bytes calldata data, uint256 delay) external onlyGovernor returns (uint256) {
        require(delay >= minDelay, "Timelock: delay too short");
        uint256 id = ++actionCount;
        uint256 eta = block.timestamp + delay;
        actions[id] = Action({ target: target, data: data, eta: eta, executed: false });
        emit QueueAction(id, target, data, eta);
        return id;
    }

    function executeAction(uint256 id) external onlyGovernor {
        Action storage a = actions[id];
        require(!a.executed, "Timelock: executed");
        require(block.timestamp >= a.eta, "Timelock: eta not reached");
        a.executed = true;
        // For safety we only support a limited set of operations: pause toggles and param setters.
        // If target == address(0) and data is encoded as: (bytes32 moduleKey, bool paused) => toggle pause
        if (a.target == address(0)) {
            // decode pause toggle
            (bytes32 moduleKey, bool paused) = abi.decode(a.data, (bytes32, bool));
            pausedModules[moduleKey] = paused;
            emit TogglePause(moduleKey, paused);
        } else {
            // call target with data
            (bool ok, ) = a.target.call(a.data);
            require(ok, "Timelock: external call failed");
        }
        emit ExecuteAction(id);
    }

    function isPaused(string calldata moduleName) external view returns (bool) {
        bytes32 key = keccak256(abi.encodePacked(moduleName));
        return pausedModules[key];
    }
}
