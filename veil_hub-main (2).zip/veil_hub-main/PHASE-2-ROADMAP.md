# Phase 2 Roadmap — Q3 2026

Scope
- Timeframe: Q3 2026 (roadmap milestones that target feature completion by quarter end).
- Focus: cross-chain indices, advanced risk tooling, composable derivatives, improved UX, and protocol-grade scaling/ops.

Top-Level Goals
- 1) Phantom Indices v1.5: expanded index templates, programmable reweights, and deeper liquidity adapters.
- 2) Cross-Chain Settlement: bridge adapters for major L1s and fast settlement via Supra relayers.
- 3) Derivatives Suite: options and perpetuals modules integrated with index feeds.
- 4) Risk & Monitoring: on-chain risk score, automated rebalancing safeguards, slippage protections.
- 5) Developer Platform: SDKs, subgraph updates, and reference integrations.

Planned Features (detailed)
- Phantom Indices Enhancements
  - Dynamic weighting strategies (momentum/value blends).
  - Index governance templates enabling community-managed index lifecycles.

- Cross-Chain Settlement
  - Integrate Supra relayer patterns for trust-minimized cross-chain messages.
  - Asset residency checks + canonical mapping for wrapped assets.

- Derivatives Suite
  - Collateralized options vault with settlement against indices.
  - Risk-adjusted margin model and liquidation mechanics tailored for indices.

- Risk & Monitoring
  - Real-time on-chain risk oracle exposing volatility and concentration metrics.
  - Circuit-breaker policies: automated pausing and reweight cooldowns on extreme events.

- Developer Platform
  - TypeScript + Rust SDKs for index creation and strategy backtesting.
  - Subgraph schema expanded to include index events, reweights, and fee flows.

Operational & Security
- Formal verification for critical contracts (indices, settlement, and staking).
- Mandatory external audits for major modules before mainnet enablement.
- Operational runbooks for on-call relayers and treasury actions.

Success Criteria
- Production-grade index TVL >= $50M within 6 months of launch.
- Cross-chain settlement enabled on at least two L1s with end-to-end tests.
- Zero critical severity audit findings on release candidates.

Dependencies & Risks
- Reliance on Supra relayer uptime and oracle integrity.
- Liquidity fragmentation across chains — mitigate via incentives and LP programs.

Timeline (milestone examples)
- April–May 2026: design and specification; SDKs skeleton.
- June 2026: alpha index contracts + testnet cross-chain messaging.
- July 2026: audits & incentives design.
- August–September 2026: mainnet launch and post-launch stabilization.
