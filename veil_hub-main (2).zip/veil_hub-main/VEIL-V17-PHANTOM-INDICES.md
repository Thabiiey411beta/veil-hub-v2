++# VEIL V17 — Phantom Indices Mechanics
++
++Overview
++- Phantom indices are on-chain index-like products representing weighted baskets of underlying assets without necessarily minting a tradable ERC20 basket token. They provide exposure, reweighting mechanics, and settlement primitives tailored for Veil Hub.
++
++Core Components
++- Index Definition: immutable metadata (name, symbol, assets list, weighting algorithm, rebalance cadence).
++- Reweight Engine: governance or strategy-driven module that schedules rebalances and computes target weights.
++- Oracles: price oracles for each underlying asset with aggregation and staleness checks.
++- Settlement Layer: logic for realizing rebalances — either via on-chain trades through AMMs or via synthetic settlement using collateral pools.
++
++Index Lifecycle
++- Create: governance or authorized factory mints an index definition with initial weights.
++- Weight Update: reweight proposals can be scheduled automatically by strategy or triggered by governance.
++- Rebalance Execution: when triggered, the engine computes trade orders and executes via configured liquidity adapters.
++
++Weighting Strategies
++- Static: fixed weights until governance updates.
++- Market-cap: weights proportional to market capitalization (or adjusted free-float).
++- Risk parity: weights inversely proportional to volatility; uses historical volatility oracle.
++- Hybrid strategies: blend signals (momentum + value) with configurable smoothing.
++
++Fees & Economics
++- Reweight Fee: small fee on assets rebalanced; split to treasury and buyback (default split 60/40).
++- Streaming Fee: optional continuous management fee charged to index positions; accrues to treasury and stakers.
++- Slippage Buffer: configurable slippage parameter included in reorder estimation to avoid front-run sandwich attacks.
++
++Minting & Synthetic Exposure
++- Phantom indices may provide synthetic exposure via collateral-backed positions rather than minting an asset representing the basket.
++- Collateral Pools: users deposit collateral (stable asset) and receive P-Index exposure via a ledger entry; collateral is used to hedge exposures off-chain or on-chain.
++
++> Security: Reweight Safety
++- On-chain transaction atomicity where possible; otherwise, break rebalances into micro-steps with checkpoints.
++- Minimum liquidity threshold checks before executing large rebalances.
++- Governance timelocks for parameter changes and reweight strategy updates.
++
++Risk Controls
++- Concentration caps per asset.
++- Emergency pause for index on oracle failure or extreme slippage.
++- Circuit-breakers: revert planned reweights if projected slippage > threshold.
++
++Oracles & Pricing
++- Primary price feeds via Supra-enabled relayers or vetted oracles.
++- Aggregation and sanity checks (median of sources, window checks, max price drift thresholds).
++
++Integration Notes
++- Adapter pattern for AMMs and order-routing; allows extension to new liquidity sources without changing core index logic.
++- Events emitted for every reweight step, fee charged, and collateral movement to facilitate subgraphs and frontends.
++
++Governance Considerations
++- Index lifecycles, fee rates, and allowed assets managed by governance modules; index creators may propose launch incentives via treasury grants.
++