# Veil Hub vImmortal — Whitepaper (Concise)

Abstract
Veil Hub vImmortal is designed as a sustainable, highly secure DeFi organism for Supra L1 combining AMMs, perpetuals, lending, vaults restaking and treasury management. Security is built on the Move resource model, oracle verification, and governance timelocks. Sustainability is enforced through built-in insurance funding and restaking management.

Design Goals
- Safety-first: timelocks, circuit breakers, oracle checks, and insurance reserves.
- Composability: modular Move files designed to interoperate atomically.
- Upgrade readiness: hooks for RWA, external oracle feeds (SupraNova), and AI governance assistant integration.

Architecture
- Governance & Timelock: Single governance resource stores pause flags and queues TimelockAction objects with a minimum 48-hour delay. Modules read and apply queued actions via safe entry points.
- Treasury & InsuranceFund: Revenue flows into Treasury; for the first 24 months, 5–10% of revenue is automatically sequestered into InsuranceFund. Governance can adjust the percentage via timelock.
- veVEIL & Gauges: veveil mints time-locked NFTs that decay-to-burn; dark_gauges allocate emissions weighted by veVEIL positions.
- Lending & Debt: phantom_lender and debt_engine enforce 150–200% O/C; debt_engine follows a zero-liquidation design for resilient settlements.
- Perpetuals: perpetual_dex supports external oracle hooks (SupraNova) and includes a circuit breaker triggered by volatility thresholds.
- Restaking & LP management: phantom_restaker and lp_vacuum manage small restake allocations (1–2%) to capture yield sustainably.

Security Mechanisms
- Move Resource Model: resources prevent reentrancy and unsafe state sharing.
- Oracle Validations: cross-module oracle reads and sanity checks guard pricing and volatility inputs.
- Circuit Breakers: per-module pause flags and specific circuit_tripped flags for perps and critical flows.
- Governance Timelocks: queue & apply pattern; all critical param changes require 48h delay.
- Insurance Fund: dedicated resource for slashing/restaking coverage, seeded automatically from revenue.

Tokenomics
- VEIL supply controlled via veil_token with mint/burn governance hooks.
- Revenue split examples: Insurance 5–10% (first 24 months), Treasury remainder, Restaker 1–2% of revenue, MEV capture flows into Treasury/Insurance.

Upgrade Readiness (v1.1)
- RWA: phantom_yield_spectrum supports adding tokenized treasury instruments via governance.
- External Perp Feeds: perpetual_dex accepts external oracle feed addresses for integration with SupraNova / Hyperliquid.
- AI Governance Assistant Hook: placeholder entrypoints for receiving ML-guided veVEIL strategy suggestions.

Safety Note: The current implementation in move_modules/ is target-agnostic Move pseudocode skeletons. For deployment on a specific Move chain (Sui/Aptos/Supra), adapt storage maps, event emission, and build tooling accordingly.

Operational Guidelines
- Deploy governance first, then core contracts using an operator/deployer account.
- Use governance::queue_action for any critical change (fee changes, insurance %, pause toggles). Enforce minimum 48h delay on the governance queue.
- Monitor on-chain oracles and configure volatility thresholds conservatively; prefer smaller fee windows and human-in-the-loop for first months.

Roadmap
1. v1.0: Core modules with timelocks, insurance auto-seeding, and circuit breakers (this repo).
2. v1.1: RWA integration, SupraNova perp feeds, AI governance assistant hook integration, audited gas and stress-testing.
3. v2.0: Cross-chain indexing, formal verification and optional multisig governance enhancements.

Appendix: Notion Import
- To publish this whitepaper on Notion: copy-paste the Markdown or use Notion's Import -> Markdown file option. Include attachments and link to the move_modules/ directory for code reference.
