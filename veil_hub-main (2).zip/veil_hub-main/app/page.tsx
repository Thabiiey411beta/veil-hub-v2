"use client"
import React from 'react'
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'

const sampleData = [
  { t: 'Jan', v: 800 },
  { t: 'Feb', v: 920 },
  { t: 'Mar', v: 860 },
  { t: 'Apr', v: 980 },
  { t: 'May', v: 1100 },
  { t: 'Jun', v: 1050 },
  { t: 'Jul', v: 1200 },
]

export default function Page() {
  return (
    <div className="min-h-screen">
      <section className="relative h-screen flex items-center">
        <div className="absolute inset-0 -z-10">
          <div className="absolute -left-36 -top-36 w-[70vmin] h-[70vmin] rounded-full opacity-40" style={{
            background: 'radial-gradient(circle at 30% 30%, rgba(139,92,246,0.18), transparent 25%), radial-gradient(circle at 70% 70%, rgba(236,72,153,0.12), transparent 20%), #000'
          }} />
          <div className="absolute -right-36 -bottom-36 w-[50vmin] h-[50vmin] rounded-full opacity-30" style={{
            background: 'radial-gradient(circle at 40% 40%, rgba(236,72,153,0.14), transparent 20%), rgba(0,0,0,0.6)'
          }} />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/60" />
        </div>

        <div className="relative z-10 max-w-6xl mx-auto px-6 text-center">
          <h1 className="text-4xl md:text-6xl font-extrabold leading-tight">Veil Hub: The Final DeFi Organism</h1>
          <p className="mt-4 text-lg text-gray-300 max-w-3xl mx-auto">Real monthly USDC dividends. Permanent token burn. Privacy-protected everything. One dApp to rule DeFi.</p>

          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button className="px-6 py-3 rounded-md bg-gradient-to-r from-violet-500 to-pink-500 text-black font-semibold">Connect Wallet</button>
            <button className="px-6 py-3 rounded-md border border-gray-700 text-gray-100">Lock VEIL &amp; Boost Yield</button>
          </div>
        </div>
      </section>

      <section className="-mt-20 relative z-20">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-gray-900/60 p-6 rounded-lg border border-gray-800">
              <div className="text-sm text-gray-400">TVL</div>
              <div className="mt-2 text-2xl font-semibold">$3.24B</div>
              <div className="mt-3 h-16">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={sampleData} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#8b5cf6" stopOpacity={0.6} />
                        <stop offset="100%" stopColor="#ec4899" stopOpacity={0.05} />
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="t" hide />
                    <YAxis hide />
                    <Tooltip wrapperStyle={{ background: '#0b0b0d', borderRadius: 8 }} />
                    <Area type="monotone" dataKey="v" stroke="#8b5cf6" fill="url(#g1)" strokeWidth={2} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-gray-900/60 p-6 rounded-lg border border-gray-800">
              <div className="text-sm text-gray-400">Annual Revenue</div>
              <div className="mt-2 text-2xl font-semibold">$412M</div>
            </div>

            <div className="bg-gray-900/60 p-6 rounded-lg border border-gray-800">
              <div className="text-sm text-gray-400">Circulating Supply</div>
              <div className="mt-2 text-2xl font-semibold">180M VEIL</div>
              <div className="mt-3 w-full bg-gray-800 rounded-full h-3 overflow-hidden">
                <div className="h-3 bg-gradient-to-r from-violet-500 to-pink-500" style={{ width: '57%' }} />
              </div>
            </div>

            <div className="bg-gray-900/60 p-6 rounded-lg border border-gray-800">
              <div className="text-sm text-gray-400">Your Estimated Dividend</div>
              <div className="mt-2 text-xl font-medium text-gray-300">Connect to view</div>
            </div>
          </div>

          <div className="mt-12">
            <h2 className="text-2xl font-semibold">Features</h2>
            <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {[
                ['⚔️','Perps Trading'],
                ['🏦','Advanced Lending'],
                ['🛡️','Auto Vaults'],
                ['🔗','Yield Tokenization'],
                ['🔁','Dual Restaking'],
                ['📈','Phantom Indices'],
                ['🔒','Encrypted Governance'],
              ].map(([emoji, title])=> (
                <div key={String(title)} className="bg-gray-900/50 p-4 rounded-lg border border-gray-800 flex items-start gap-3">
                  <div className="text-2xl">{emoji}</div>
                  <div>
                    <div className="font-semibold">{title}</div>
                    <div className="text-sm text-gray-400">Modern, composable primitives</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-12 mb-24">
            <h2 className="text-2xl font-semibold">How It Works</h2>
            <div className="mt-6 bg-gray-900/50 p-6 rounded-lg border border-gray-800 text-center">
              <div className="text-lg font-medium">Revenue → Dividends + Burn → Scarcity → Higher Yields → More TVL</div>
              <div className="mt-4 text-sm text-gray-400">(Animated flywheel placeholder)</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
