import React from 'react'

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap" rel="stylesheet" />
      </head>
      <body className="font-sans bg-[#0f0f1a] text-gray-100 antialiased min-h-screen flex flex-col">
        <header className="w-full py-4 px-6 md:px-12 flex items-center justify-between border-b border-gray-900">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-gradient-to-br from-violet-500 to-pink-500 flex items-center justify-center font-bold text-black">V</div>
            <span className="text-lg font-semibold">Veil Hub</span>
          </div>

          <nav className="hidden md:flex gap-6 items-center">
            <a href="#" className="text-sm text-gray-300 hover:text-white">Docs</a>
            <a href="#" className="text-sm text-gray-300 hover:text-white">Whitepaper</a>
            <a href="#" className="text-sm text-gray-300 hover:text-white">Discord</a>
            <a href="#" className="text-sm text-gray-300 hover:text-white">X</a>
          </nav>

          <div className="ml-auto">
            <button className="px-4 py-2 rounded-md bg-gradient-to-r from-violet-500 to-pink-500 text-black font-medium shadow-lg">Connect Wallet</button>
          </div>
        </header>

        <main className="flex-grow">{children}</main>

        <footer className="w-full border-t border-gray-900 py-6 px-6 md:px-12">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-sm text-gray-400">© {new Date().getFullYear()} Veil Hub</div>
            <div className="flex gap-4">
              <a href="#" className="text-sm text-gray-300 hover:text-white">Docs</a>
              <a href="#" className="text-sm text-gray-300 hover:text-white">Whitepaper</a>
              <a href="#" className="text-sm text-gray-300 hover:text-white">Discord</a>
              <a href="#" className="text-sm text-gray-300 hover:text-white">X</a>
            </div>
          </div>
        </footer>
      </body>
    </html>
  )
}
